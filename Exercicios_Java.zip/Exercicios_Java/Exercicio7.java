public class Exercicio7 {
    public static void main(String[] args) {
        String[] desenho = {
                "    *",
                "   * *",
                "  *   *",
                " *     *",
                "***   ***",
                "  *   *",
                "  *   *",
                "  *****"
        };
        for (String linha : desenho) {
            System.out.println(linha);
        }
    }
}
